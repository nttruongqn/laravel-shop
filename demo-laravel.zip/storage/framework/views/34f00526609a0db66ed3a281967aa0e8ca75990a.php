<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
<body>
  <div class="wrapper">
  error 404

  </div>
</body>
</html>
<?php /**PATH C:\Users\ADMIN\Desktop\demo-laravel\resources\views/index.blade.php ENDPATH**/ ?>