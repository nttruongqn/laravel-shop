<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Module Admin</title>

       
       

    </head>
    <body>
        <?php echo $__env->yieldContent('content'); ?>

        
        
    </body>
</html>
<?php /**PATH C:\Users\ADMIN\Desktop\demo-laravel\Modules/Admin\Resources/views/layouts/master.blade.php ENDPATH**/ ?>